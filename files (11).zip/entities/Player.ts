export class Player {
  position = { x: 0, y: 12, z: 0 };
  inventory: Record<string, number> = {};
  status: string = "normal";

  spawn(point: { x: number, y: number, z: number }) {
    this.position = { ...point };
  }

  update() {
    // Movement, input, actions, camera, etc.
  }

  addToInventory(item: string, amount: number = 1) {
    if (!this.inventory[item]) this.inventory[item] = 0;
    this.inventory[item] += amount;
  }
}