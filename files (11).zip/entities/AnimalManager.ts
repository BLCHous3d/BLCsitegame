import { TimeWeatherSystem } from "../core/TimeWeatherSystem";
import { WorldGenerator } from "../core/WorldGenerator";

export interface Animal {
  type: string;
  position: { x: number, y: number, z: number };
  status: string;
  comfort: [number, number];
}

export class AnimalManager {
  animals: Animal[] = [];
  timeWeather: TimeWeatherSystem;
  world: WorldGenerator;

  constructor(timeWeather: TimeWeatherSystem, world: WorldGenerator) {
    this.timeWeather = timeWeather;
    this.world = world;
    for (let i = 0; i < 60; i++) {
      const x = Math.random() * 350 - 175;
      const z = Math.random() * 350 - 175;
      const biome = world.getBiomeAt(x, z);
      this.animals.push({
        type: biome.animals[Math.floor(Math.random() * biome.animals.length)] || "Rabbit",
        position: { x, y: 0, z },
        status: "normal",
        comfort: [0, 30]
      });
    }
  }

  update() {
    // Improve: migration, herding, AI based on weather/season
    for (const animal of this.animals) {
      // Example: animals seek comfort zones, herd up, etc.
    }
  }
}