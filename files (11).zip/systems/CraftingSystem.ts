export class CraftingSystem {
  recipes: Record<string, { ingredients: Record<string, number>, output: string, amount: number }> = {
    "Campfire": { ingredients: { "Wood": 3, "Stone": 2 }, output: "Campfire", amount: 1 },
    "Stone Axe": { ingredients: { "Wood": 1, "Stone": 2 }, output: "Axe", amount: 1 }
    // Add more!
  };

  craft(item: string, inventory: Record<string, number>): boolean {
    const recipe = this.recipes[item];
    if (!recipe) return false;
    for (const [ing, qty] of Object.entries(recipe.ingredients)) {
      if (!inventory[ing] || inventory[ing] < qty) return false;
    }
    for (const [ing, qty] of Object.entries(recipe.ingredients)) {
      inventory[ing] -= qty;
    }
    inventory[recipe.output] = (inventory[recipe.output] || 0) + recipe.amount;
    return true;
  }
}