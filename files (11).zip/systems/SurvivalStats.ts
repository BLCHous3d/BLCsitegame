import { Player } from "../entities/Player";
import { TimeWeatherSystem } from "../core/TimeWeatherSystem";

export class SurvivalStats {
  player: Player;
  timeWeather: TimeWeatherSystem;
  hunger: number = 100;
  thirst: number = 100;
  stamina: number = 100;
  temperature: number = 37;
  health: number = 100;

  constructor(player: Player, timeWeather: TimeWeatherSystem) {
    this.player = player;
    this.timeWeather = timeWeather;
  }

  update() {
    // Drain stats over time
    this.hunger -= 0.003;
    this.thirst -= 0.004;
    this.stamina -= 0.002;
    this.temperature = this.computeTemperature();

    if (this.hunger < 15 || this.thirst < 15 || this.temperature < 35 || this.temperature > 39) {
      this.health -= 0.015;
    } else if (this.health < 100) {
      this.health += 0.004;
    }
    // Clamp
    this.hunger = Math.max(0, Math.min(100, this.hunger));
    this.thirst = Math.max(0, Math.min(100, this.thirst));
    this.stamina = Math.max(0, Math.min(100, this.stamina));
    this.health = Math.max(0, Math.min(100, this.health));
  }

  computeTemperature(): number {
    let temp = 37;
    if (this.timeWeather.weather === "Snow") temp -= 4;
    if (this.timeWeather.weather === "Rain") temp -= 1.2;
    if (this.timeWeather.season === "Winter") temp -= 2.5;
    if (this.timeWeather.hour >= 18 || this.timeWeather.hour < 6) temp -= 0.6;
    // TODO: biome, clothing, fire, shelter, etc.
    return temp;
  }
}