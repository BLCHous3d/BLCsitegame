import { Player } from "../entities/Player";
import { SurvivalStats } from "../systems/SurvivalStats";
import { TimeWeatherSystem } from "../core/TimeWeatherSystem";
import { CraftingSystem } from "../systems/CraftingSystem";
import { BuildingSystem } from "../systems/BuildingSystem";

export class UIManager {
  player: Player;
  stats: SurvivalStats;
  timeWeather: TimeWeatherSystem;
  crafting: CraftingSystem;
  building: BuildingSystem;

  constructor(player: Player, stats: SurvivalStats, timeWeather: TimeWeatherSystem, crafting: CraftingSystem, building: BuildingSystem) {
    this.player = player;
    this.stats = stats;
    this.timeWeather = timeWeather;
    this.crafting = crafting;
    this.building = building;
  }

  init() {
    // Render HUD, inventory, minimap, etc.
  }

  update() {
    // Update HUD; show stats, weather, minimap, etc.
  }
}