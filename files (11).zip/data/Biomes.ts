export interface Biome {
  name: string;
  color: number;
  elevation: number;
  trees: string[];
  rocks: string[];
  animals: string[];
  plants: string[];
}

export const BIOMES: Biome[] = [
  { name: "Alpine", color: 0xcccccc, elevation: 40, trees: ["Pine"], rocks: ["Granite"], animals: ["Mountain Goat"], plants: ["Alpine Grass"] },
  { name: "Tundra", color: 0xe0e0e0, elevation: 25, trees: [], rocks: ["Limestone"], animals: ["Caribou"], plants: [] },
  { name: "Boreal", color: 0x556b2f, elevation: 16, trees: ["Spruce", "Fir"], rocks: ["Granite"], animals: ["Wolf"], plants: ["Berry Bush"] },
  { name: "Temperate", color: 0x228b22, elevation: 8, trees: ["Oak", "Maple"], rocks: ["Sandstone"], animals: ["Deer"], plants: ["Wildflower"] },
  { name: "Grassland", color: 0x9acd32, elevation: 4, trees: ["Birch"], rocks: ["Quartzite"], animals: ["Rabbit"], plants: ["Tall Grass"] },
  { name: "Desert", color: 0xf4e285, elevation: 1, trees: [], rocks: ["Sandstone"], animals: ["Lizard"], plants: ["Cactus"] },
  { name: "Rainforest", color: 0x228b22, elevation: 10, trees: ["Mahogany"], rocks: ["Granite"], animals: ["Jaguar"], plants: ["Fern"] },
  { name: "Taiga", color: 0x7bb661, elevation: 14, trees: ["Pine", "Spruce"], rocks: ["Granite"], animals: ["Moose"], plants: [] }
];