import { GameManager } from "./core/GameManager";

window.onload = () => {
  const game = new GameManager();
  game.start();
};