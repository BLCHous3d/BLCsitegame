import { Biome } from "../data/Biomes";

export class Chunk {
  static SIZE = 64;
  cx: number;
  cz: number;
  biome: Biome | undefined;

  constructor(cx: number, cz: number) {
    this.cx = cx;
    this.cz = cz;
    // Generate terrain, place objects, etc.
  }
}