import { WorldGenerator } from "./WorldGenerator";
import { Player } from "../entities/Player";
import { TimeWeatherSystem } from "./TimeWeatherSystem";
import { SurvivalStats } from "../systems/SurvivalStats";
import { CraftingSystem } from "../systems/CraftingSystem";
import { BuildingSystem } from "../systems/BuildingSystem";
import { AnimalManager } from "../entities/AnimalManager";
import { UIManager } from "../ui/UIManager";

export class GameManager {
  world: WorldGenerator;
  player: Player;
  timeWeather: TimeWeatherSystem;
  stats: SurvivalStats;
  crafting: CraftingSystem;
  building: BuildingSystem;
  animals: AnimalManager;
  ui: UIManager;

  constructor() {
    this.world = new WorldGenerator();
    this.player = new Player();
    this.timeWeather = new TimeWeatherSystem();
    this.stats = new SurvivalStats(this.player, this.timeWeather);
    this.crafting = new CraftingSystem();
    this.building = new BuildingSystem();
    this.animals = new AnimalManager(this.timeWeather, this.world);
    this.ui = new UIManager(this.player, this.stats, this.timeWeather, this.crafting, this.building);
  }

  start() {
    this.world.init();
    this.player.spawn(this.world.getSpawnPoint());
    this.ui.init();
    this.mainLoop();
  }

  mainLoop() {
    requestAnimationFrame(() => this.mainLoop());
    this.timeWeather.update();
    this.stats.update();
    this.world.updateAround(this.player.position);
    this.animals.update();
    this.player.update();
    this.ui.update();
    // Add rendering logic here
  }
}