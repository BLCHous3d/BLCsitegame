import { Biome, BIOMES } from "../data/Biomes";
import { Chunk } from "./Chunk";

export class WorldGenerator {
  chunks: Map<string, Chunk> = new Map();

  init() {
    // Preload initial chunk(s)
    this.loadChunk(0, 0);
  }

  getSpawnPoint() {
    return { x: 0, y: 12, z: 0 };
  }

  chunkKey(cx: number, cz: number) {
    return `${cx},${cz}`;
  }

  loadChunk(cx: number, cz: number) {
    const key = this.chunkKey(cx, cz);
    if (!this.chunks.has(key)) {
      this.chunks.set(key, new Chunk(cx, cz));
    }
  }

  updateAround(pos: { x: number, z: number }) {
    const cx = Math.floor(pos.x / Chunk.SIZE);
    const cz = Math.floor(pos.z / Chunk.SIZE);
    for (let dx = -2; dx <= 2; dx++) {
      for (let dz = -2; dz <= 2; dz++) {
        this.loadChunk(cx + dx, cz + dz);
      }
    }
    // Optionally: Unload distant chunks for performance
  }

  getBiomeAt(x: number, z: number): Biome {
    // Real implementation: Perlin/Simplex noise for smooth transitions
    // Demo: deterministic selection
    const idx = Math.abs(Math.floor((x + z) / 100) % BIOMES.length);
    return BIOMES[idx];
  }
}