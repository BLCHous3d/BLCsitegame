export class TimeWeatherSystem {
  hour: number = 8; // 0-24
  day: number = 1;
  season: string = "Spring";
  weather: string = "Clear"; // "Rain", "Snow", etc.
  totalMinutesElapsed: number = 0;

  update() {
    this.totalMinutesElapsed += 1; // 1 tick = 1 minute; tune as needed
    this.hour = (this.totalMinutesElapsed / 60) % 24;
    if (this.hour === 0) this.day++;
    if (this.day % 30 === 0) {
      const seasons = ["Spring", "Summer", "Autumn", "Winter"];
      this.season = seasons[Math.floor(this.day / 30) % 4];
    }
    // Weather logic (random for demo)
    if (Math.random() < 0.002) {
      this.weather = ["Clear", "Rain", "Storm", "Snow"][Math.floor(Math.random() * 4)];
    }
  }
}